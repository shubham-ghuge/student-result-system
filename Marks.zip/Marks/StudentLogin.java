package Marks;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class StudentLogin {

    JFrame jf2;
    JTextField t1;
    JPasswordField t2;
    JLabel l, l1, l2;
    JButton b1, b2;
    Font f;

    public StudentLogin() {
        jf2 = new JFrame("Student Login");
        t1 = new JTextField();
        t2 = new JPasswordField();

        l = new JLabel("Credentials: ");
        l1 = new JLabel("UserID:");
        l2 = new JLabel("Password:");

        b1 = new JButton("Generate: ");
        b2 = new JButton("Reset");

        jf2.add(t1);
        jf2.add(t2);

        jf2.add(l);
        jf2.add(l1);
        jf2.add(l2);

        jf2.add(b1);
        jf2.add(b2);

        jf2.setSize(500, 400);
        jf2.setLayout(null);

        jf2.setVisible(true);
        jf2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    }

    public void set() {
        l.setBounds(150, 20, 150, 20);
        l1.setBounds(100, 60, 100, 20);
        l2.setBounds(100, 100, 100, 20);

        t1.setBounds(240, 60, 100, 20);
        t2.setBounds(240, 100, 100, 20);

        b1.setBounds(120, 200, 80, 20);
        b2.setBounds(220, 200, 80, 20);

        b1.addActionListener((ActionEvent ae) -> {
            try {
                DBConnection co = new DBConnection();
                int check = co.checkstudentlogin(Integer.parseInt(t1.getText()), t2.getText());
                if (check != 0) {
                    JOptionPane.showMessageDialog(jf2, "Login Successful!");
                    //jf2.dispose();

                    Marksheet r = new Marksheet();
                    System.out.println(check);
                    r.set(check);
                    jf2.dispose();
                }
            } catch (Exception ex) {
            }
        });

        b2.addActionListener((ActionEvent ae) -> {
            t1.setText("");
            t2.setText("");
        });
    }

    public String getName() {
        return t1.getText();
    }

    public String getLocation() {
        return t2.getText();
    }
}
