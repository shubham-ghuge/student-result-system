package Marks;

import java.awt.event.ActionEvent;
import java.sql.*;
import javax.swing.*;

public class FirstPage {

    JFrame jf;
    JLabel l;
    JButton b1, b2, b3, b4;
    static Connection con;

    FirstPage() throws Exception {
        jf = new JFrame("MARKSHEET GENERATOR");
        l = new JLabel("WELCOME TO MARKSHEET GENERATOR");
        b1 = new JButton("Teacher login");
        b2 = new JButton("Student login");
        jf.setLayout(null);
        jf.setSize(450, 200);
        l.setSize(400, 10);
        jf.add(l);
        jf.add(b1);
        jf.add(b2);
        l.setBounds(100, 20, 400, 20);
        b1.setBounds(120, 60, 200, 20);
        b2.setBounds(120, 100, 200, 20);

        jf.setVisible(true);
        jf.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Class.forName("oracle.jdbc.driver.OracleDriver");
        con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "system");
    }

    public void event() {
        b1.addActionListener((ActionEvent ae) -> {
            TeacherLogin u = new TeacherLogin();
            u.set();
        });
        b2.addActionListener((ActionEvent ae) -> {
            try {
                StudentLogin sl = new StudentLogin();
                sl.set();
            } catch (Exception ex) {
            }
        });

    }

    public static void main(String[] args) throws Exception {
        FirstPage fp = new FirstPage();
        fp.event();
    }
}
