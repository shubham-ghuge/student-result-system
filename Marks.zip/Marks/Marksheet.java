package Marks;

import java.awt.*;
import static java.awt.Font.ITALIC;
import java.awt.event.ActionEvent;
import javax.swing.*;

public class Marksheet {

    JFrame jf2;
    JLabel t1, t2, t3, t4, t5;
    JLabel l, l1, l2, l3, l4, l5;
    JButton b1, b2;
    Font f;

    Marksheet() {
        jf2 = new JFrame("MARKSHEET");
        t1 = new JLabel();
        t2 = new JLabel();
        t3 = new JLabel();
        t4 = new JLabel();
        t5 = new JLabel();

        l = new JLabel("PERSONAL DETAILS:");
        l1 = new JLabel("Name:");
        l2 = new JLabel("Location:");
        l3 = new JLabel("Date of Birth:");
        l4 = new JLabel("Mobile No:");
        l5 = new JLabel("Email ID:");

        b1 = new JButton("OK");

        jf2.add(t1);
        jf2.add(t2);
        jf2.add(t3);
        jf2.add(t4);
        jf2.add(t5);
        jf2.add(l);
        jf2.add(l1);
        jf2.add(l2);
        jf2.add(l3);
        jf2.add(l4);
        jf2.add(l5);
        jf2.add(b1);

        jf2.setSize(500, 400);
        jf2.setLayout(null);

        jf2.setVisible(true);
        jf2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        f = new Font("Serif", ITALIC, 15);
        l.setFont(f);
    }

    public void set(int id) throws Exception {
        DBConnection c = new DBConnection();
        Student k = c.generatemarksheet(id);
        l.setText("Name: " + k.getName() + "                                ID: " + id);
        l1.setText("Java:");
        l2.setText("DS:");
        l3.setText("Maths:");
        l4.setText("Total:");
        l5.setText("Percentage:");

        l.setBounds(100, 20, 300, 20);
        l1.setBounds(140, 60, 100, 20);
        l2.setBounds(140, 100, 100, 20);
        l3.setBounds(140, 140, 100, 20);
        l4.setBounds(140, 180, 100, 20);
        l5.setBounds(140, 220, 100, 20);

        t1.setBounds(240, 60, 100, 20);
        t2.setBounds(240, 100, 100, 20);
        t3.setBounds(240, 140, 100, 20);
        t4.setBounds(240, 180, 100, 20);
        t5.setBounds(240, 220, 100, 20);

        b1.setBounds(120, 270, 80, 20);

        t1.setText(String.valueOf(k.getJava()));
        t2.setText(String.valueOf(k.getDs()));
        t3.setText(String.valueOf(k.getMaths()));
        t4.setText(String.valueOf(k.getTotal()));
        t5.setText(String.valueOf(k.getTotal() / 3));

        b1.addActionListener((ActionEvent e) -> {
            jf2.dispose();
        });
    }
}
