package Marks;

import java.awt.*;
import static java.awt.Font.ITALIC;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;

public class MarksEntry {

    JFrame jf2;
    JTextField t1, t2, t3, t4, t5;
    JLabel l, l1, l2, l3, l4, l5;
    JButton b1, b2;
    Font f;

    MarksEntry() {
        jf2 = new JFrame("Marks Entry");
        t1 = new JTextField();
        t2 = new JTextField();
        t3 = new JTextField();
        t4 = new JTextField();
        t5 = new JTextField();

        l = new JLabel();
        l1 = new JLabel();
        l2 = new JLabel();
        l3 = new JLabel();
        l4 = new JLabel();
        l5 = new JLabel();

        b1 = new JButton("Submit");
        b2 = new JButton("Reset");

        jf2.add(t1);
        jf2.add(t2);
        jf2.add(t3);
        jf2.add(t4);
        jf2.add(t5);
        jf2.add(l);
        jf2.add(l1);
        jf2.add(l2);
        jf2.add(l3);
        jf2.add(l4);
        jf2.add(l5);
        jf2.add(b1);
        jf2.add(b2);

        jf2.setSize(500, 400);
        jf2.setLayout(null);

        jf2.setVisible(true);
        jf2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        f = new Font("Serif", ITALIC, 15);
        l.setFont(f);
    }

    public void set(String subject) throws Exception {
        DBConnection c = new DBConnection();
        int nos[] = new int[5];
        ResultSet rst = c.select();
        int i = 0;
        while (rst.next()) {
            nos[i++] = rst.getInt(1);
        }
        String tr = c.getTeacher(subject);
        l.setText("Welcome " + tr + "! Enter marks for " + subject);
        l1.setText(String.valueOf(nos[0]) + ":");
        l2.setText(String.valueOf(nos[1]) + ":");
        l3.setText(String.valueOf(nos[2]) + ":");
        l4.setText(String.valueOf(nos[3]) + ":");
        l5.setText(String.valueOf(nos[4]) + ":");

        l.setBounds(100, 20, 300, 20);
        l1.setBounds(140, 60, 100, 20);
        l2.setBounds(140, 100, 100, 20);
        l3.setBounds(140, 140, 100, 20);
        l4.setBounds(140, 180, 100, 20);
        l5.setBounds(140, 220, 100, 20);

        t1.setBounds(240, 60, 100, 20);
        t2.setBounds(240, 100, 100, 20);
        t3.setBounds(240, 140, 100, 20);
        t4.setBounds(240, 180, 100, 20);
        t5.setBounds(240, 220, 100, 20);

        b1.setBounds(120, 270, 80, 20);
        b2.setBounds(220, 270, 80, 20);

        b1.addActionListener((ActionEvent ae) -> {
            try {
                c.update(subject, nos[0], Integer.parseInt(t1.getText()));
                c.update(subject, nos[1], Integer.parseInt(t2.getText()));
                c.update(subject, nos[2], Integer.parseInt(t3.getText()));
                c.update(subject, nos[3], Integer.parseInt(t4.getText()));
                c.update(subject, nos[4], Integer.parseInt(t5.getText()));

                JOptionPane.showMessageDialog(jf2, "Data inserted successfully!");
                jf2.dispose();
            } catch (HeadlessException | NumberFormatException | SQLException ex) {
                System.out.println(ex.toString());
            }
        });

        b2.addActionListener((ActionEvent ae) -> {
            t1.setText("");
            t2.setText("");
            t3.setText("");
            t4.setText("");
            t5.setText("");
        });
    }
}
