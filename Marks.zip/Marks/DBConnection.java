package Marks;

import java.sql.*;

public class DBConnection {

    Connection con;
    PreparedStatement ps;
    Statement st;
    ResultSet rs;
    String s;

    public DBConnection() throws Exception {
        Class.forName("oracle.jdbc.driver.OracleDriver");
        con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "system");
    }

    public int checkstudentlogin(int id, String password) throws Exception {
        ps = con.prepareStatement("select password from student where userid=?");
        ps.setInt(1, id);
        rs = ps.executeQuery();
        while (rs.next()) {
            if (password.equals(rs.getString(1))) {
                return id;
            } else {
                return 0;
            }
        }
        return 0;
    }

    public String getTeacher(String userid) throws SQLException {

        ps = con.prepareStatement("select name from teacher where subject=?");
        ps.setString(1, userid);
        rs = ps.executeQuery();
        while (rs.next()) {
            return rs.getString(1);
        }
        return null;

    }

    public String checkteacherlogin(int id, String password) throws Exception {
        ps = con.prepareStatement("select password, subject from teacher where userid=?");
        ps.setInt(1, id);
        rs = ps.executeQuery();
        while (rs.next()) {
            if (password.equals(rs.getString(1))) {
                return rs.getString(2);
            } else {
                return null;
            }
        }
        return null;
    }

    public ResultSet select() throws Exception {
        st = con.createStatement();
        rs = st.executeQuery("select userid from student");

        return rs;
    }

    public void update(String subject, int id, int mks) throws SQLException {
        st = con.createStatement();
        st.executeQuery("update student set " + subject + " = " + mks + " where userid= " + id);
        ps = con.prepareStatement("update student set Maths=? where userid=?");
    }

    public Student generatemarksheet(int userid) throws SQLException {
        Student obj = new Student();
        String s = "Select * from student where userid=?";
        ps = con.prepareStatement(s);
        ps.setInt(1, userid);
        rs = ps.executeQuery();
        while (rs.next()) {
            obj.setName(rs.getString(1));
            obj.setUserid(rs.getInt(2));
            obj.setJava(rs.getInt(4));
            obj.setDs(rs.getInt(5));
            obj.setMaths(rs.getInt(6));
        }
        obj.setTotal(obj.getDs() + obj.getJava() + obj.getMaths());
        String s2 = "update student set total=?where userid=?";
        ps = con.prepareStatement(s2);
        ps.setInt(1, obj.getTotal());
        ps.setInt(2, userid);
        rs = ps.executeQuery();

        return obj;
    }

}
